#pragma parameter compositeConnection "[GTU]  Composite Connection Enable" 0.0 0.0 1.0 1.0

#define FIXNUM 6